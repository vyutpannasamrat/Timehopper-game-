#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <iostream>
#include <string>
#include <vector>
using namespace sf;

int main() {
    RenderWindow window(VideoMode(800, 600), "Time Hopper - Pixel");

    // Colors
    Color bgColor(30, 30, 40);
    Color cubeColor(255, 50, 50);
    Color legColor(80, 10, 10);
    Color orbColor(100, 255, 200);
    Color obstacleColor(255, 255, 0);

    // Cube (player)
    RectangleShape body(Vector2f(30, 30));
    body.setFillColor(cubeColor);
    body.setPosition(100, 400);

    RectangleShape legLeft(Vector2f(8, 15));
    legLeft.setFillColor(legColor);

    RectangleShape legRight(Vector2f(8, 15));
    legRight.setFillColor(legColor);

    // Ground level
    float groundY = 430;

    // Orb (collectible)
    CircleShape orb(10);
    orb.setFillColor(orbColor);
    orb.setPosition(600, groundY);

    // Obstacle
    RectangleShape obstacle(Vector2f(30, 30));
    obstacle.setFillColor(obstacleColor);
    obstacle.setPosition(800, groundY);

    // Font and score text
    Font font;
    if (!font.loadFromFile("C:/Windows/Fonts/consola.ttf")) {
        std::cout << "Font load failed!" << std::endl;
        return -1;
    }

    Text scoreText;
    scoreText.setFont(font);
    scoreText.setCharacterSize(24);
    scoreText.setFillColor(Color::White);
    scoreText.setPosition(10, 10);

    int score = 0;

    // Progress bar
    RectangleShape progressBar(Vector2f(0, 10));
    progressBar.setFillColor(Color::Green);
    progressBar.setPosition(10, 50);

    // Jump variables
    float velocityY = 0;
    bool isJumping = false;
    float gravity = 0.6f;

    // Leg animation
    bool legToggle = false;
    Clock legClock;

    // Particle system
    std::vector<CircleShape> particles;

    // Orb Respawn
    Clock orbRespawnClock;
    bool orbCollected = false;

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed)
                window.close();

            if (event.type == Event::MouseButtonPressed && !isJumping) {
                velocityY = -12;
                isJumping = true;

                // Add particles
                for (int i = 0; i < 5; ++i) {
                    CircleShape spark(2);
                    spark.setFillColor(Color::White);
                    spark.setPosition(
                        body.getPosition().x + rand() % 30,
                        body.getPosition().y + rand() % 10
                    );
                    particles.push_back(spark);
                }
            }
        }

        // Update physics
        velocityY += gravity;
        body.move(2, velocityY);

        if (body.getPosition().y > groundY) {
            body.setPosition(body.getPosition().x, groundY);
            velocityY = 0;
            isJumping = false;
        }

        // Legs animation
        legLeft.setPosition(body.getPosition().x + (legToggle ? 2 : 6), body.getPosition().y + 30);
        legRight.setPosition(body.getPosition().x + (legToggle ? 20 : 16), body.getPosition().y + 30);
        if (legClock.getElapsedTime().asMilliseconds() > 150) {
            legToggle = !legToggle;
            legClock.restart();
        }

        // Orb collision and respawn
        if (!orbCollected && body.getGlobalBounds().intersects(orb.getGlobalBounds())) {
            orb.setPosition(-100, -100);
            score += 1;
            orbCollected = true;
            orbRespawnClock.restart();
        }

        if (orbCollected && orbRespawnClock.getElapsedTime().asSeconds() > 5.f) {
            orb.setPosition(600, groundY);
            orbCollected = false;
        }

        // Obstacle movement and collision
        obstacle.move(-4, 0);
        if (obstacle.getPosition().x < -30)
            obstacle.setPosition(800, groundY);

        if (body.getGlobalBounds().intersects(obstacle.getGlobalBounds())) {
            score = std::max(0, score - 1);
            obstacle.setPosition(800, groundY);
        }

        // Update progress bar and score
        progressBar.setSize(Vector2f(score * 10, 10));
        scoreText.setString("Score: " + std::to_string(score));

        // Draw everything
        window.clear(bgColor);
        window.draw(body);
        window.draw(legLeft);
        window.draw(legRight);
        window.draw(orb);
        window.draw(obstacle);
        window.draw(scoreText);
        window.draw(progressBar);

        // Draw particles (and clear)
        for (auto& spark : particles)
            window.draw(spark);
        particles.clear();

        window.display();
    }

    return 0;
}