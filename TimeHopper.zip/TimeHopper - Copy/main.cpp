#include <SFML/Graphics.hpp>
using namespace sf;

int main() {
    RenderWindow window(VideoMode(800, 600), "Time Hopper");

    Texture backgroundTexture, cubeTexture, orbTexture;
    backgroundTexture.loadFromFile("assets/background.png");
    cubeTexture.loadFromFile("assets/cube.png");
    orbTexture.loadFromFile("assets/orb.png");

    Sprite background(backgroundTexture);
    background.setScale(800.0f / backgroundTexture.getSize().x,
                        600.0f / backgroundTexture.getSize().y);

    Sprite cube(cubeTexture);
    cube.setScale(0.1f, 0.1f);
    cube.setPosition(100, 400);

    Sprite orb(orbTexture);
    orb.setScale(0.05f, 0.05f);
    orb.setPosition(600, 400);

    float velocityY = 0;
    bool isJumping = false;
    float gravity = 0.5f;

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed)
                window.close();

            if (event.type == Event::MouseButtonPressed) {
                if (!isJumping) {
                    velocityY = -12;
                    isJumping = true;
                }
            }
        }

        velocityY += gravity;
        cube.move(2, velocityY);

        if (cube.getPosition().y > 400) {
            cube.setPosition(cube.getPosition().x, 400);
            velocityY = 0;
            isJumping = false;
        }

        window.clear();
        window.draw(background);
        window.draw(cube);
        window.draw(orb);
        window.display();
    }

    return 0;
}
